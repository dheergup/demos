﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Capgemini.Demos.Day1

{
    public partial class StandardControls02 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnTechnology_Command(object sender, CommandEventArgs e)
        {
            if (e.CommandName.Equals("dotnet"))
                lblResults.Text = "Dotnet Technology : " + e.CommandArgument.ToString();
            else
                lblResults.Text = "JEE Technology: " + e.CommandArgument.ToString();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {



        }

        protected void btnDecision_Click(object sender, EventArgs e)
        {
            lblResults.Text = "Yes i am Accepting this";
        }

        protected void ibtnImage_Click(object sender, ImageClickEventArgs e)
        {
            string position = string.Format("X : {0} Y:{1} ",e.X,e.Y);
            lblPosition.Text = position; 
        }

       
    }
}
