﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Capgemini.Demos.Day1
{
    public partial class ValidationControls04 : System.Web.UI.Page
    {

        protected void Page_Init(object sender, EventArgs e)
        {
            Random r = new Random();
            lblSample.Text = r.Next(9000, 9999).ToString();
            valValueCompare.ValueToCompare = lblSample.Text;
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
