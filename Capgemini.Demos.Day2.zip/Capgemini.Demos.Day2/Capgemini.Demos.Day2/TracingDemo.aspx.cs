﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Capgemini.Demos.Day2
{
    public partial class TracingDemo : System.Web.UI.Page
    {
        int firstNumber;
        int secondNumber;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSample_Click(object sender, EventArgs e)
        {
            firstNumber = 10;
            secondNumber = 20;
            int addResult, multiplyResult;

            addResult = firstNumber + secondNumber;
            Trace.Write("addition done created by Aishwarya");
            multiplyResult = firstNumber * secondNumber;
            Trace.Write("Multiplication Done by Aishwarya");

            string result = String.Format("Additon = {0} and Multiplication={1}", addResult, multiplyResult);
            Response.Write(result);

            Trace.Write("Calling Sample Method");
            Sample();
            Trace.Write("Sample Method calling done");
        }

        private void Sample()
        {
            ArrayList list = new ArrayList();
            list.Add("VB.NET");
            list.Add("C#");
            list.Add("ASP.NET");
            list.Add("LINQ");

            Session["Session_Data"] = list;
            Application["Application_Data"] = list;
        }

       
        
    }
}
