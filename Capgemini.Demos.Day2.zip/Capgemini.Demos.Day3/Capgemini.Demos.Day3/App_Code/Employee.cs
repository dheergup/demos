﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;

namespace Capgemini.Demos.Day3.AppCode
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public int Salary { get; set; }


        public List<Employee> GetAllEmployees()
        {
            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee { EmployeeId = 101, EmployeeName = "John", Salary = 2300 });
            empList.Add(new Employee { EmployeeId = 102, EmployeeName = "Peter", Salary = 4500 });
            empList.Add(new Employee { EmployeeId = 103, EmployeeName = "David", Salary = 1500 });
            return empList;
        }

    }
}
