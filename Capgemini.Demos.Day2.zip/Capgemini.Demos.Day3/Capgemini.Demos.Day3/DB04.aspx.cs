﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Capgemini.Demos.Day3
{
    public partial class DB04 : System.Web.UI.Page
    {
        string strCity = "";
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void ddlCity_PreRender(object sender, EventArgs e)
        {
            DropDownList ddlCity = (DropDownList)sender;
            ddlCity.SelectedIndex = ddlCity.Items.IndexOf(ddlCity.Items.FindByText(strCity));

        }

        protected void gvStudent_RowEditing(object sender, GridViewEditEventArgs e)
        {
            strCity = ((Label)gvStudent.Rows[e.NewEditIndex].FindControl("lblCity")).Text;
        }

        protected void gvStudent_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            //To Get Primary Colum Value of Gridview
            // int studentID = (int)gvStudent.DataKeys[e.RowIndex].Value;
            //string studentName = ((TextBox)gvStudent.Rows[e.RowIndex].Cells[1].Controls[0]).Text;
            string cityID = ((DropDownList)gvStudent.Rows[e.RowIndex].Cells[2].Controls[1]).SelectedItem.Value;
            SqlDataSource1.UpdateParameters["CityID"].DefaultValue = cityID;

        }
    }
}
