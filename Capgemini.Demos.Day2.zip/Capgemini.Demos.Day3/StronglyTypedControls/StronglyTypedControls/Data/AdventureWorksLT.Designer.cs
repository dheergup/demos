﻿// Default code generation is disabled for model 'F:\Technologies\VS2012\Course New features of Asp.Net 4.5 for Asp.Net 3.5 Developers\Daywise\Day 2\StronglyTypedControls\StronglyTypedControls\StronglyTypedControls\Data\AdventureWorksLT.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.