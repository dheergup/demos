﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StronglyTypedControls.Data
{
    public partial class Customer
    {
        public string FullName {
            get
            {
                return this.FirstName + " " + this.LastName;
            }
        }
    }
}