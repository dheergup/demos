﻿using StronglyTypedControls.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StronglyTypedControls
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCustomers();
            }
        }

        protected void CustomersDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindOrders();
        }

        private void BindCustomers()
        {
            using (var context = new AdventureWorksLT_DataEntities())
            {
                var custs = (from cust in context.Customers
                             join order in context.SalesOrderHeaders on cust.CustomerID equals order.CustomerID
                             orderby cust.LastName
                             select cust).ToList();
                CustomersDropDown.DataSource = custs;
                CustomersDropDown.DataBind();
            }
        }

        private void BindOrders()
        {
            var customerID = int.Parse(CustomersDropDown.SelectedValue);
            using (var context = new AdventureWorksLT_DataEntities())
            {
                var orders = (from c in context.SalesOrderHeaders
                              where c.CustomerID == customerID
                              orderby c.OrderDate
                              select c).ToList();
                OrdersListView.DataSource = orders;
                OrdersListView.DataBind();
            }
        }

        protected void OrdersListView_ItemEditing(object sender, ListViewEditEventArgs e)
        {
            OrdersListView.EditIndex = e.NewEditIndex;
            BindOrders();
        }

        protected void OrdersListView_ItemCanceling(object sender, ListViewCancelEventArgs e)
        {
            OrdersListView.EditIndex = -1;
            BindOrders();
        }

        protected void OrdersListView_ItemUpdating(object sender, ListViewUpdateEventArgs e)
        {
            var orderID = int.Parse(((Label)GetControl(e, "OrderID")).Text);
            var orderDate = DateTime.Parse(((TextBox)GetControl(e, "OrderDate")).Text);
            var dueDate = DateTime.Parse(((TextBox)GetControl(e, "DueDate")).Text);
            var shipDate = DateTime.Parse(((TextBox)GetControl(e, "ShipDate")).Text);
            var subTotal = decimal.Parse(((TextBox)GetControl(e, "SubTotal")).Text);
            using (var context = new AdventureWorksLT_DataEntities())
            {
                var order = context.SalesOrderHeaders.Find(orderID);
                if (order != null)
                {
                    order.OrderDate = orderDate;
                    order.DueDate = dueDate;
                    order.ShipDate = shipDate;
                    order.SubTotal = subTotal;

                    //context.Entry(order).State = System.Data.EntityState.Modified;
                    try
                    {
                        context.SaveChanges();
                        OrdersListView.EditIndex = -1;
                        BindOrders();
                        ErrorLabel.Text = String.Empty;
                    }
                    catch (Exception exp)
                    {
                        ErrorLabel.Text = exp.Message;
                    }                        
                }
            }
        }

        private Control GetControl(ListViewUpdateEventArgs e, string id)
        {
            return OrdersListView.Items[e.ItemIndex].FindControl(id);
        }
    }
}