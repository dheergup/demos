﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.IO;

namespace Capgemini.Demos.Day4
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            Application["pageHit"] = null;
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            Session["SampleSession"] = null;
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception ex = Server.GetLastError();
            string errorFile = Server.MapPath(@"ErrorLog\Error.txt");
            FileStream fs = new FileStream(errorFile, FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine("------------------------------------------------------------------------");
            sw.WriteLine("Exception occured at {0}", DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt"));
            sw.WriteLine(ex.InnerException.Message);
            sw.WriteLine("Printing StackTrace ...");
            sw.WriteLine(ex.InnerException.StackTrace.ToString());
            sw.WriteLine("------------------------------------------------------------------------");
            sw.Write(Environment.NewLine);
            sw.Close();
            fs.Close();
        }

        protected void Session_End(object sender, EventArgs e)
        {
            Session.Abandon();
        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}