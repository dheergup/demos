﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Capgemini.Demos.Day4.StateManagement
{
    public partial class StateManagement01 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnStoreCookie_Click(object sender, EventArgs e)
        {
            HttpCookie cook1 = new HttpCookie("SampleCookie");
            cook1.Value = txtStoreCookie.Text;
            cook1.Expires = DateTime.Now.AddSeconds(20);
            Response.Cookies.Add(cook1);
            ClientScript.RegisterStartupScript(this.GetType(), "", "<script>alert('Cookie Created')</script>");
        }

        protected void btnRetrieveCookie_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["SampleCookie"] != null)
            {
                txtRetrieveCookie.Text = Request.Cookies["SampleCookie"].Value;
            }
        }

        protected void btnCreateSession_Click(object sender, EventArgs e)
        {
          //  txtCreateSession.Text = Guid.NewGuid().ToString();
            if (Session["SampleSession"] == null)
            {
                Session["SampleSession"] = txtCreateSession.Text;
            }
        }

        protected void btnRetrieveSession_Click(object sender, EventArgs e)
        {
            if (Session["SampleSession"] != null)
            {
                txtRetrieveSession.Text = Session["SampleSession"].ToString();
            }
        }

   

        protected void btnCreateViewState_Click(object sender, EventArgs e)
        {
            //txtCreateViewState.Text = Guid.NewGuid().ToString();
            if (ViewState["SampleView"] == null)
            {
                ViewState["SampleView"] = txtCreateViewState.Text;
            }
        }

        protected void btnRetrieveViewState_Click(object sender, EventArgs e)
        {
            if (ViewState["SampleView"] != null)
            {
                txtRetrieveViewState.Text = ViewState["SampleView"].ToString();
            }
        }

      
    }
}
