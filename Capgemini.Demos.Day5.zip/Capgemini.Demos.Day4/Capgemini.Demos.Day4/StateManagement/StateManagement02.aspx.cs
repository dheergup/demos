﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Capgemini.Demos.Day4.StateManagement
{
    public partial class StateManagement02 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSession_Click(object sender, EventArgs e)
        {
            if (Session["SampleSession"] != null)
            {
                lblSession.Text = Session["SampleSession"].ToString();
            }
        }

        protected void btnViewState_Click(object sender, EventArgs e)
        {
            if (ViewState["SampleView"] != null)
            {
                lblViewState.Text = ViewState["SampleView"].ToString();
            }
        }

        protected void btnPageHit_Click(object sender, EventArgs e)
        {
            int counter = 1;
            if (Application["pageHit"] == null)
            {

                Application["pageHit"] = counter;
            }
            else
            {
                counter = (int)Application["pageHit"];
                counter = counter + 1;
                Application["pageHit"] = counter;
            }
            string hitResult =  String.Format("Page Visited for {0} Times.",counter);
            lblPageHit.Text = hitResult;
        }

        protected void btnSessionID_Click(object sender, EventArgs e)
        {
            txtSessionID.Text = Session.SessionID.ToString();
        }

        
    }
}
