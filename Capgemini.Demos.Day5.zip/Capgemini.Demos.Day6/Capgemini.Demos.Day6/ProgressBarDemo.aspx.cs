﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;

namespace Capgemini.Demos.Day6
{
    public partial class ProgressBarDemo : System.Web.UI.Page
    {
        public string GetStockPrice()
        {
            double val = 200 + new Random().NextDouble();
            return val.ToString();
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Thread.Sleep(2000);
            Label1.Text = GetStockPrice();   
        }
    }
}