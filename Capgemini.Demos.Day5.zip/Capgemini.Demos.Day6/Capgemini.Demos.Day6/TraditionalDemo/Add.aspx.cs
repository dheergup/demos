using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int a = 0;
        int b = 0;
        if (Request.Params["A"] != null)
        {
            a = Convert.ToInt32(Request.Params["A"].ToString());
        }
        if (Request.Params["B"] != null)
        {
            b = Convert.ToInt32(Request.Params["B"].ToString());
        }
        Response.Clear();
        Response.ContentType = "text/html";
        Response.Write(a + b);
        Response.End();
    }
}
